from mesa.space import Grid
from agent import Robot, Piso
from model import Limpieza
from mesa.visualization.modules import CanvasGrid
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.UserParam import UserSettableParameter


def portrayalLimpieza(agent):
    portrayal = {"Shape": "circle",
                 "Filled": "true",
                 "Layer": 0,
                 "Color": "red",
                 "r": 0.5}

    if (isinstance(agent, Piso)):
        if(agent.condition == "Dirty"):
            portrayal["Color"] = "grey"
            portrayal["Layer"] = 1
            portrayal["r"] = 0.2
        else:
            portrayal["Color"] = "black"
            portrayal["Layer"] = 1
            portrayal["r"] = 0.2

    return portrayal


model_params = {"N": UserSettableParameter("slider", "Limpieza: ", 1, 1, 5, 1), "width": 10, "height": 10, "porcentaje": UserSettableParameter(
    "slider", "Porcentaje: ", 0.1, 0.1, 1, 0.1), "tiempo_max": UserSettableParameter("slider", "Tiempo max: ", 30, 10, 50, 5)}  # slider
# para que se vea en el grid y haga la simulacion
canvas_element = CanvasGrid(portrayalLimpieza, 10, 10, 500, 500)
server = ModularServer(Limpieza, [canvas_element], "Limpieza", model_params)
# podemos tener más de 1 canvas element
server.launch()
