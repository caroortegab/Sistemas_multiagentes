from mesa import Agent


class Piso(Agent):
    def _init_(self, pos, model, estado_inicial="Clean"):

        super()._init_(pos, model)
        self.pos = pos
        self.state = estado_inicial


class Robot(Agent):

    def _init_(self, model, id):

        super()._init_(model, id)
        self.direction = 4

    def move(self):
        # neighborhood da las posiciones de los vecinos que se tengan que limpiar
        # regresa una lista de celdas que estan en el punto
        possible_steps = self.model.grid.get_neighborhood(
            self.pos,
            moore=True,  # es como parte del neighborhood
            include_center=True)

        if(len(possible_steps) <= self.direction):
            pass
        else:
            self.model.grid.move_agent(self, possible_steps[self.direction])

        #self.model.grid.move_agent(self, possible_steps[self.direction])
    def step(self):

        # regresa lista de cntenidos en esa posicion
        # revisa el estado del 1 elemento, piso=>revisa, cambia o mueve
        if(isinstance(self.model.grid[self.pos][0], Piso)):
            if (self.model.grid[self.pos][0].condition == "Sucio"):
                self.model.grid[self.pos][0].condition = " Limpio"
            else:
                self.direction = self.random.randint(0, 8)
                self.move()

        else:
            self.direction = self.random.randint(0, 8)
            self.move()


"""

    def step(self):
        
        determina la nueva direccion
        
        self.direction = self.random.randint(0, 8)

    # checar celda en la que esta, buscar estado de piso y en base a eso limpiar o no. una vez limpio espera una vuelta para ver a donde se mueve.

    def limpiar(self):
        if(self.condition == "Dirty"):
            self.condition = "Clean"
"""
